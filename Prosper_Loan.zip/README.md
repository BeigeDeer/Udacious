# Prosper Loan Data
## by Kufre John


## Dataset

The dataset contained 81 columns and 113937 rows of borrowers data on Prosper, but after filtering the dataset, the new dataset used for analysis contained 16 columns and 113937 rows.


## Summary of Findings

1) There is a negative relationship between Prosper Rating and Debt to Income Ratio; this implies that the lesser the debt to income ratio of borrowers, the higher their rating score.

2) That a higher borrower's rating score is accompanied by a reduced rate charge on the loan. this means that an increase in borrowers' rating score causes an increase in the loan term to a minute degree.

3) That employment status does have an effect on the magnitude of amount to be borrowed, this is attributed to having a steady source of income which provides confidence the loan will be repaid.

4) There is a slight negative relationship between Loan amount and Borrower APR; that is,as loan amount increases,the annual percentage rate on the loan tends to decrease.

5) It is observed that a very large number of borrowers are Employed, followed by Full time workers; Part time workers, Unemployed and Retirees borrow the least.

6) Profesionals,Computer Programmers,Executives, Teachers and Administrative Assistants are respectively the top 5 Occupation of borrowers on Prosper; Students, judges and Dentists are the least represented.
 
7) C is the highest loan rating in the dataset and it serves as the mid point of loan ratings; AA which is the highest possible loan rating has the least count.

8) Values of Borrowers' APR as well as Borrowers' rate appears to be slightly evenly distributed with no visible skews or outliers,thus implying a standard range of rates is bing maintained.

9) 77% of borrowers use the loan term period of 36 months,21.5% borrow for 60 months; 12 months is the least exploited option with just a little over 1% of respondents opting for it.

10) The highest rating scores are distributed at around the midrange(between 4 and 8)with 4 having the highest rating counts and the mean rating capped at 6.11,1 are have the least rates respectively.

11) It is observed that debt to income ratio is highly skewed to the right,this shows that a very large amount of borrowers keep a good debt to income level.

12) Majority of borrowers borrow between 1000 and 10000 ,with the mean amount roughly at 6000. The highest borrowed amount is 35000

13) It is observed from the plot that a weak but positive relationship exists between Prosper Rating and Loan Term; this means that an increase in borrowers' rating score causes an increase in the loan term to a minute degree.

14) It is observed that the relationship beeween loan term and ProsperRating becomes negative when ProsperRating is considered with respect to BorrowerRate.

15) The Employment status of a borrower relatively affects the degree to which they would borrow and how long the loan term will be,we can observe that an employed borrower borrows fairly higher amounts than an unemployed borrower on average while opting more for a shorter loan term of 12 months instead of the 60 months greatly favoured by the unemployed.

## Key Insights for Presentation

1) There is a negative relationship between Prosper Rating and Debt to Income Ratio; this implies that the lesser the debt to income ratio of borrowers, the higher their rating score.

2) The Employment status of a borrower relatively affects the degree to which they would borrow and how long the loan term will be,we can observe that an employed borrower borrows fairly higher amounts than an unemployed borrower on average while opting more for a shorter loan term of 12 months instead of the 60 months greatly favoured by the unemployed.
